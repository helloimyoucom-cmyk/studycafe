const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Serve static files from the /public folder
app.use(express.static('public'));

// Store recent messages so new users see chat history
const recentMessages = [];
const MAX_HISTORY = 50;

io.on('connection', (socket) => {
  console.log('A user connected');

  // Send last 50 messages to the newly connected user
  recentMessages.forEach((msg) => {
    socket.emit('chat message', msg);
  });

  // When a message is received, broadcast it to everyone
  socket.on('chat message', (data) => {
    const message = {
      user: data.user,
      text: data.text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    recentMessages.push(message);
    if (recentMessages.length > MAX_HISTORY) recentMessages.shift();

    io.emit('chat message', message); // send to ALL connected users
  });

  socket.on('disconnect', () => {
    console.log('A user disconnected');
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Study Café server running on port ${PORT}`);
});
