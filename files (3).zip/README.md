# ☕ Study Café

A virtual study café with real-time multi-user chat, built with Node.js and Socket.io.

## Folder Structure

```
study-cafe/
├── server.js          ← Node.js backend
├── package.json       ← Dependencies
├── .gitignore
└── public/
    ├── index.html     ← Your app
    ├── cafe.jpg       ← Café background image (add your own)
    └── nyc.jpg        ← City background image (add your own)
```

---

## 🖼️ Add Your Background Images

Place two images inside the `/public` folder:
- `cafe.jpg` — shown while studying
- `nyc.jpg` — shown when outside

You can use any `.jpg` images you like. Free options: [Unsplash](https://unsplash.com)

---

## 🚀 Deploy to Railway (free)

1. Push this repo to GitHub
2. Go to [railway.app](https://railway.app) → **New Project**
3. Click **Deploy from GitHub repo** → select this repo
4. Railway auto-detects Node.js and runs `npm start`
5. Click **Generate Domain** to get your public URL

Done! Share the URL with anyone.

---

## 💻 Run Locally

```bash
npm install
npm start
```

Then open: http://localhost:3000
